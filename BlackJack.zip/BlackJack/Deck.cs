﻿/* Homework 4
 * Edwin Aramburo
 * CMIS 1301: Programming for Games 1
 * Semester: Spring 2020
 *
 *
 *
 */


using System;
namespace Blackjack
{
/* CLASS: Desk
 * STATIC PRIVATE FIELDS: None
 * STATIC PUBLIC FILEDS: None
 * NON-STATIC PRIVATE FIELDS: None
 * NON-STATIC PUBLIC FIELDS: Card, int random_num, int fail_count, int count, Card shuffledDeck, Card masterOrderedDeck
 * STATIC PRIVATE METHODS: None
 * STATIC PUBLIC METHODS: None
 * NON-STATIC PRIVATE METHODS: None
 * NON-STATIC PUBLIC METHODS: Deck, SelctRandomCard, CheckRandomSelection, InsertRandomCard, Shuffle, PrintDeck 
 *
 * DESCRIPTION: Creates a mastered deck that is ordered, and an empty deck that has empty cards
 * then all the empty cards are assigned randomly from the master deck
 *
 * VERSION/DATE: 1.0 / 04-28 
 */
    public class Deck
    {

        //this is the deck that will contain the shuffled cards
        public Card[,] shuffledDeck = new Card[4, 13];

        //brand new Deck where all cards are in order
        public Card[,] masterOrderedDeck = new Card[4, 13]
        {
            //row 0 for 13 cols - Spades
            {
            new Card(Suit.S, Rank._A),new Card(Suit.S, Rank._2),new Card(Suit.S, Rank._3),new Card(Suit.S, Rank._4),
            new Card(Suit.S, Rank._5),new Card(Suit.S, Rank._6),new Card(Suit.S, Rank._7),new Card(Suit.S, Rank._8),new Card(Suit.S, Rank._9),
            new Card(Suit.S, Rank._10),new Card(Suit.S, Rank._J),new Card(Suit.S, Rank._Q),new Card(Suit.S, Rank._K)
            },

            //row 1 for 13 cols - Clubs
             {
            new Card(Suit.C, Rank._A),new Card(Suit.C, Rank._2),new Card(Suit.C, Rank._3),new Card(Suit.C, Rank._4),
            new Card(Suit.C, Rank._5),new Card(Suit.C, Rank._6),new Card(Suit.C, Rank._7),new Card(Suit.C, Rank._8),new Card(Suit.C, Rank._9),
            new Card(Suit.C, Rank._10),new Card(Suit.C, Rank._J),new Card(Suit.C, Rank._Q),new Card(Suit.C, Rank._K)
            },

             //row 2 for 13 cols - Hearts
             {
            new Card(Suit.H, Rank._A),new Card(Suit.H, Rank._2),new Card(Suit.H, Rank._3),new Card(Suit.H, Rank._4),
            new Card(Suit.H, Rank._5),new Card(Suit.H, Rank._6),new Card(Suit.H, Rank._7),new Card(Suit.H, Rank._8),new Card(Suit.H, Rank._9),
            new Card(Suit.H, Rank._10),new Card(Suit.H, Rank._J),new Card(Suit.H, Rank._Q),new Card(Suit.H, Rank._K)
            },
              //row 3 for 13 cols - Diamonds
               {
            new Card(Suit.D, Rank._A),new Card(Suit.D, Rank._2),new Card(Suit.D, Rank._3),new Card(Suit.D, Rank._4),
            new Card(Suit.D, Rank._5),new Card(Suit.D, Rank._6),new Card(Suit.D, Rank._7),new Card(Suit.D, Rank._8),new Card(Suit.D, Rank._9),
            new Card(Suit.D, Rank._10),new Card(Suit.D, Rank._J),new Card(Suit.D, Rank._Q),new Card(Suit.D, Rank._K)
            },

        };


        /* METHOD: Deck()
         * PARAMS: None
         * RETURNS: None
         * CLASS SCOPE EFFECTS: shuffledDeck
         * CALLED FUNCTIONS: Shuffle, PrintDeck
         * 
         * DESCRIPTION: When a deck is initialized the deck will be shuffled and the content
         * will be printed
         * 
         * VERSION/DATE: 1.0/ 4-28
        */

        public Deck()
        {
            Shuffle();

            Console.WriteLine("Shuffling.....");

            PrintDeck();
        }


        /* METHOD: SelectRandomCard()
          * PARAMS: None
          * RETURNS: void
          * CLASS SCOPE EFFECTS: random_num, count, fail_count
          * CALLED FUNCTIONS: CheckRandomSelection, SelectRandomCard
          * 
          * DESCRIPTION: This will select a random card from the masteredordered deck, and check to see if
          * this card has already been selected previously if not then it will select, if so then another
          * random card will be selected
          * 
          * VERSION/DATE: 1.0/ 4-28
         */

        int random_num;
        int count;
        int fail_count;

        Random r = new Random();


        public void SelectRandomCard()
        {
            count++;

            random_num = r.Next(52);

            //Console.WriteLine(random_num);

            if (CheckRandomSelection(random_num))
            {
                fail_count = 0;
                return;
            }
            else
            {
                fail_count++;
                SelectRandomCard();
            }


        }
        /* METHOD: CheckRandomSelection()
          * PARAMS: int elem
          * RETURNS:bool
          * CLASS SCOPE EFFECTS: masterOrderedDeck[].isUsed
          * CALLED FUNCTIONS: None
          * 
          * DESCRIPTION: This will check if the selected card has been used before,
          * and change its isUsed value to true if not. 
          * 
          * VERSION/DATE: 1.0/ 4-28
         */



        public bool CheckRandomSelection(int elem)
        {
            if (!masterOrderedDeck[(int)elem / 13, elem % 13].isUsed)
            {
                masterOrderedDeck[(int)elem / 13, elem % 13].isUsed = true;
                return true;
            }
            else
            {
                return false;
            }

        }
        /* METHOD: InsertRandomCard()
          * PARAMS: None
          * RETURNS:Card
          * CLASS SCOPE EFFECTS: Card random_card, masterOrderDeck[]
          * CALLED FUNCTIONS: SelectRandomCard(), Card()
          * 
          * DESCRIPTION: This will create an empty card and assign it a random card from
          * the masterOrderedDeck
          * 
          * VERSION/DATE: 1.0/ 4-28
         */

        public Card InsertRandomCard()
        {
            //Empty card
            Card random_card = new Card();

            SelectRandomCard();


            random_card = masterOrderedDeck[(int)random_num / 13, random_num % 13];

            return random_card;
        }
       /* METHOD: Shuffle()
        * PARAMS: None
        * RETURNS: void
        * CLASS SCOPE EFFECTS: shuffledDeck[,]
        * CALLED FUNCTIONS: InsertRandomCard()
        * 
        * DESCRIPTION: this will assign random cards to an empty deck,
        * in other words it wil shuffle the deck
        * 
        * VERSION/DATE: 1.0/ 4-28
       */
        public void Shuffle()
        {
            //CAN BE OPTIMIZED
            shuffledDeck[0, 0] = InsertRandomCard();
            shuffledDeck[0, 1] = InsertRandomCard();
            shuffledDeck[0, 2] = InsertRandomCard();
            shuffledDeck[0, 3] = InsertRandomCard();
            shuffledDeck[0, 4] = InsertRandomCard();
            shuffledDeck[0, 5] = InsertRandomCard();
            shuffledDeck[0, 6] = InsertRandomCard();
            shuffledDeck[0, 7] = InsertRandomCard();
            shuffledDeck[0, 8] = InsertRandomCard();
            shuffledDeck[0, 9] = InsertRandomCard();
            shuffledDeck[0, 10] = InsertRandomCard();
            shuffledDeck[0, 11] = InsertRandomCard();
            shuffledDeck[0, 12] = InsertRandomCard();

            shuffledDeck[1, 0] = InsertRandomCard();
            shuffledDeck[1, 1] = InsertRandomCard();
            shuffledDeck[1, 2] = InsertRandomCard();
            shuffledDeck[1, 3] = InsertRandomCard();
            shuffledDeck[1, 4] = InsertRandomCard();
            shuffledDeck[1, 5] = InsertRandomCard();
            shuffledDeck[1, 6] = InsertRandomCard();
            shuffledDeck[1, 7] = InsertRandomCard();
            shuffledDeck[1, 8] = InsertRandomCard();
            shuffledDeck[1, 9] = InsertRandomCard();
            shuffledDeck[1, 10] = InsertRandomCard();
            shuffledDeck[1, 11] = InsertRandomCard();
            shuffledDeck[1, 12] = InsertRandomCard();

            shuffledDeck[2, 0] = InsertRandomCard();
            shuffledDeck[2, 1] = InsertRandomCard();
            shuffledDeck[2, 2] = InsertRandomCard();
            shuffledDeck[2, 3] = InsertRandomCard();
            shuffledDeck[2, 4] = InsertRandomCard();
            shuffledDeck[2, 5] = InsertRandomCard();
            shuffledDeck[2, 6] = InsertRandomCard();
            shuffledDeck[2, 7] = InsertRandomCard();
            shuffledDeck[2, 8] = InsertRandomCard();
            shuffledDeck[2, 9] = InsertRandomCard();
            shuffledDeck[2, 10] = InsertRandomCard();
            shuffledDeck[2, 11] = InsertRandomCard();
            shuffledDeck[2, 12] = InsertRandomCard();

            shuffledDeck[3, 0] = InsertRandomCard();
            shuffledDeck[3, 1] = InsertRandomCard();
            shuffledDeck[3, 2] = InsertRandomCard();
            shuffledDeck[3, 3] = InsertRandomCard();
            shuffledDeck[3, 4] = InsertRandomCard();
            shuffledDeck[3, 5] = InsertRandomCard();
            shuffledDeck[3, 6] = InsertRandomCard();
            shuffledDeck[3, 7] = InsertRandomCard();
            shuffledDeck[3, 8] = InsertRandomCard();
            shuffledDeck[3, 9] = InsertRandomCard();
            shuffledDeck[3, 10] = InsertRandomCard();
            shuffledDeck[3, 11] = InsertRandomCard();
            shuffledDeck[3, 12] = InsertRandomCard();


        }
        /* METHOD: PrintDeck()
         * PARAMS: None
         * RETURNS: void
         * CLASS SCOPE EFFECTS: None
         * CALLED FUNCTIONS: Console.WriteLine()
         * 
         * DESCRIPTION: This will print out all the contents of the shuffled deck
         * 
         * VERSION/DATE: 1.0/ 4-28
        */
        public void PrintDeck()
        {
            Console.WriteLine("This is the current shuffled deck, take a look!");
            Console.WriteLine("--------------------------------------------------------");


            for (int i = 0; i <= 51; i++)
            {
                Console.WriteLine(i + " | " + "[" + (int)(i / 13) + "," + i % 13 + "] "
                    + " Suit: " + shuffledDeck[(int)(i / 13), i % 13].suit
                    + " Rank: " + shuffledDeck[(int)i / 13, i % 13].rank
                    + " value: " + shuffledDeck[(int)i / 13, i % 13].value);
            }

            Console.WriteLine("--------------------------------------------------------");
        }
    }
}
