﻿/* Homework 4
 * Edwin Aramburo
 * CMIS 1301: Programming for Games 1
 * Semester: Spring 2020
 *
 *
 *
 */

using System;
using Blackjack;

namespace BlackJack
{

 /* CLASS: CardHand
 * STATIC PRIVATE FIELDS: None
 * STATIC PUBLIC FILEDS: None
 * NON-STATIC PRIVATE FIELDS: None
 * NON-STATIC PUBLIC FIELDS: string owner_type, int score, card00 - card08 
 * STATIC PRIVATE METHODS: None
 * STATIC PUBLIC METHODS: None
 * NON-STATIC PRIVATE METHODS: None
 * NON-STATIC PUBLIC METHODS: CardHand(), DrawCard(), TallyHand()
 *
 * 
 * DESCRIPTION: The purpose of the ClassHand class is allows 8 cards max to be dealt to either player, set card equal
 * to a random card, and tally the score of each player's hand
 *
 * VERSION/DATE: 3.0 / 04-20 
 */
    public class CardHand
    {
        public string owner_type;

        Card card00 = new Card();
        Card card01 = new Card();
        Card card02 = new Card();
        Card card03 = new Card();
        Card card04 = new Card();
        Card card05 = new Card();
        Card card06 = new Card();
        Card card07 = new Card();
        Card card08 = new Card();

        public int score = 0;



        /* METHOD:CardHand()
         * PARAMS: string obj_type
         * RETURNS: None
         * CLASS SCOPE EFFECTS: owner_type
         * CALLED FUNCTIONS: None
         *  
         * DESCRIPTION: This is the constructor for the CardHand
         * 
         * VERSION/DATE: 1.0 / 4-28
         */

        public CardHand(string obj_type)
        {
            owner_type = obj_type;
        }

        /* METHOD:DrawCard(Card crd)
         * PARAMS: Card crd
         * RETURNS: void
         * CLASS SCOPE EFFECTS: card00-card08
         * CALLED FUNCTIONS: MainClass.count_deal, Console.WriteLine()
         *  
         * DESCRIPTION: This sets card00-card08 equal to a card selecting in the main program,
         * and displays its suit and rank
         * 
         * VERSION/DATE: 1.0/ 4-28
        */


        public void DrawCard(Card crd)
        {
            if(MainClass.count_deal == 0)
            {
                card00 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 1)
            {
                card01 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 2)
            {
                card02 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 3)
            {
                card03 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 4)
            {
                card04 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 5)
            {
                card05 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 6)
            {
                card06 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 7)
            {
                card07 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal == 8)
            {
                card08 = crd;
                Console.WriteLine("Suit: " + crd.suit + ", Rank: " + crd.rank);
            }
            else if (MainClass.count_deal > 8)
            {
                Console.WriteLine("The max number of cards have been dealt!");
            }


        }
        /* METHOD:TallHand()
         * PARAMS: None
         * RETURNS: void
         * CLASS SCOPE EFFECTS: int score
         * CALLED FUNCTIONS: None
         *  
         * DESCRIPTION: Sums the values of all the cards
         * 
         * VERSION/DATE: 1.0/ 4-28
        */
        public void TallyHand()
        {
            score = card00.value + card01.value + card02.value + card03.value + card04.value + card05.value + card06.value + card07.value + card08.value;
            
           
        }
    }
}
