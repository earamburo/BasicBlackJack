﻿/* Homework 4
 * Edwin Aramburo
 * CMIS 1301: Programming for Games 1
 * Semester: Spring 2020
 *
 *
 *
 * 
 * CLASS: Dealer
 * STATIC PRIVATE FIELDS: None
 * STATIC PUBLIC FILEDS: None
 * NON-STATIC PRIVATE FIELDS: None
 * NON-STATIC PUBLIC FIELDS: CardHand
 * STATIC PRIVATE METHODS: None
 * STATIC PUBLIC METHODS: None
 * NON-STATIC PRIVATE METHODS: None
 * NON-STATIC PUBLIC METHODS: None
 * 
 * DESCRIPTION:Initializes the dealer object and the dealer hand with the corresponding owner
 * 
 * VERSION/DATE: 1.0 / 04-28 
 */

using System;
namespace BlackJack
{
    public class Dealer
    {
        //Create a hand of cards for dealer
        public CardHand ch = new CardHand("Dealer");

        public Dealer()
        {
        }
    }
}