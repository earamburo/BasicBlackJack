﻿/* Homework 4
 * Edwin Aramburo
 * CMIS 1301: Programming for Games 1
 * Semester: Spring 2020
 *
 *
 *
 * CLASS: Card
 * STATIC PRIVATE FIELDS:None
 * STATIC PUBLIC FILEDS: None
 * NON-STATIC PRIVATE FIELDS: None
 * NON-STATIC PUBLIC FIELDS: Suit suit, Rank rank, bool isUsed, int value
 * STATIC PRIVATE METHODS: None
 * STATIC PUBLIC METHODS: None
 * NON-STATIC PRIVATE METHODS: None
 * NON-STATIC PUBLIC METHODS: Card(), Math.Min()
 *
 * DESCRIPTION: Initialized the Card Object with a rank, suit, a is used boolean for later purposes, and a default value of 0 for empty cards used later
 * 
 * VERSION/DATE: 1.0 / 04-28 
 */
using System;

public enum Suit { S, C, H, D };
public enum Rank { _A = 1, _2 = 2, _3 = 3, _4, _5, _6, _7, _8, _9, _10, _J, _Q, _K };

namespace Blackjack
{
    public class Card
    {

        public Suit suit;
        public Rank rank;
        public bool isUsed = false;
        public int value;




        /* METHOD:Card()
         * PARAMS: None
         * RETURNS: None
         * CLASS SCOPE EFFECTS: value
         * CALLED FUNCTIONS: None
         *  
         * DESCRIPTION: This is the constructor for the empty card type
         * 
         * VERSION/DATE: 1.0 / 4-28
         */

        public Card()
        { 
            //loads default
            value = 0;
        }


        /* METHOD:Card(Suit s, Rank r)
        * PARAMS: Suit s, Rank r
        * RETURNS: None
        * CLASS SCOPE EFFECTS: value
        * CALLED FUNCTIONS: Math.Min()
        *  
        * DESCRIPTION: This is the constructor for the type of cards with with parameters suit s and rank r, the value of the cards
        * will not go over 10, this is to deal witht he face card error
        * 
        * VERSION/DATE: 1.0 / 4-28
        */

        public Card(Suit s, Rank r)
        {
            suit = s;
            rank = r;

            //Sets a min value of 10,
            //returns the smaller of two arguments, to handle J,Q,K
            value = Math.Min((int)rank, 10);
        }
    }
}
