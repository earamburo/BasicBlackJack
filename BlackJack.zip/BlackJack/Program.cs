﻿/* Homework 4 SOLUTION
 * Edwin Aramburo
 * CMIS 1301: Programming for Games 1
 * Semester: Spring 2020
 *
 *Rules:
 * 1. Goal is to beat the dealer without going over 21
 * 2. Face cards are worth 10. Aces are worth 1. Rank cards are worth rank value
 * 3. Each player starts with one card
 * 4. HIT is to ask for another card, each card dealt as requested.
 * 5. Dealer must hit until her cards total 17 or higher
 * 6. If player goes over 21 DEAL WINS
 * 7. If dealer exceed 21 PLAYER WINS
 *
 *
 *
 *
 * Requirements Met:
 * ***THIS GAME IS READY TO PLAY!******
 * 1.	Watch the HW4 Demo video and see how the game plays in the console. Your Blackjack game must provide the same console interface and game data display as the HW4 Demo video.
 * 2.	Your code may need System.Environment.Exit() to make a final quit when winning conditions occur or it might need a break out of an outer loop. (Hint: The beginning of the game and any place where one loops back into Program.Main() are good places to use the master do/while game loop.)
 * 3.	Use the shuffling and printing of a deck that you already solved with a loop to insert cards from the masterDeck and the shuffledDeck.
 * 4.	Create a class called Hand that keeps a list of all cards dealt from shuffledDeck and added to each Hand dealerHand and Hand playerHand.
 * 5.	Use the Random Class to choose a card from the shuffledDeck to insert or add into dealerHand and playerHand.
 * 6.	Mathematically a maximum of 9 deals are possible in Blackjack with a standard deck. 9 dealt rounds of cards to each of dealerHand and playerHand should be the maximum iterated through a loop within Main() of Program or perhaps a Game class constructor if you prefer.
 * 7.	Follow the commenting template provided in the course precisely.
 * 
 *
 */


using System;
using BlackJack;

/* NAMESPACE: Blackjack
 * CLASSES: MainClass, Deck, CardHand, Card, Player, Dealer
 * ENUMS: WINNER_ID, Rank, Suit
 * 
 *
 * DESCRIPTION: The initial/gateway namespace that initializes the game and controls the structure of the game BlackJack
 *
 * VERSION/DATE: 1.0 / 04-28
 */

namespace Blackjack
{


    enum WINNER_ID { Tie, Player, Dealer, None, Undetermined };

    /* CLASS: MainClass
     * STATIC PRIVATE FIELDS: Dealer dlr, Player plr, string input, bool is_winner, player_holds, dealer_holds
     * STATIC PUBLIC FILEDS: Deck d, int count_deal
     * NON-STATIC PRIVATE FIELDS: None
     * NON-STATIC PUBLIC FIELDS: None
     * STATIC PRIVATE METHODS: none
     * STATIC PUBLIC METHODS: Main()
     * NON-STATIC PRIVATE METHODS:None
     * NON-STATIC PUBLIC METHODS: HitOrPass(), Hit(), Pass(), CheckForWinner()
     * DESCRIPTION: Primary/Gateway class that handles the games process/flow
     *
     * VERSION/DATE: 1.0 / 04-28 
     */
    class MainClass
    {
        //static fields
        static Dealer dlr;
        static Player plr;

        //Initializes deck
        static public Deck d;

        //Initialized input
        static string input;

        //Default winner
        static bool is_winner = false;

        //Set winner to undetermined as default
        static WINNER_ID winner = WINNER_ID.Undetermined;

        //Deal count, MAX is 9
        public static int count_deal = 0;

        //Hold states for both players
        static bool player_holds = false;
        static bool dealer_holds = false;


        /* METHOD: Main()
         * PARAMS: None
         * RETURNS: void
         * CLASS SCOPE EFFECTS: Dealer dlr, Player plr, Deck d, 
         * CALLED FUNCTIONS: HitOrPass(), Hit(), Pass(), CheckForWinner()
         * DESCRIPTION: The gateway function that handles the games process  
         *               
         * VERSION/DATE: 1.0 / 04-28  
         */

        public static void Main()
        {

            //MAIN RULES
            Console.WriteLine("WELCOME TO BLACKJACK");
            Console.WriteLine("RULES: ");
            Console.WriteLine("1. goal is to beat the dealer without going over 21");
            Console.WriteLine("2. Face cards are worth 10. Aces are worth 1. Rank cards are worth rank value");
            Console.WriteLine("3. Each player starts with one card");
            Console.WriteLine("4. A card will be dealt to the player and dealer");
            Console.WriteLine("5. HIT is to ask for another card, each card dealt as requested.");
            Console.WriteLine("6. Dealer must hit until her cards total 17 or higher");
            Console.WriteLine("7. If player goes over 21, DEALER WINS");
            Console.WriteLine("7. If dealer exceed 21, PLAYER WINS");

            //Game Starts
            //Initialize Pplayer and Dealer

            dlr = new Dealer();
            plr = new Player();
            //Shuffle and Display Deck
            //Initializing deck, shuffles and displays deck
            d = new Deck();

            


            for (int i = 0; i <= 9; i++)
            {
                HitOrPass();
                Console.WriteLine("--------------------------------------------------------");
                CheckForWinner();
            }

            /* METHOD: HitOrPass()
             * PARAMS: None
             * RETURNS: void
             * CLASS SCOPE EFFECTS: input, is_winner, count_deal, winner
             * 
             * CALLED FUNCTIONS: Console.ReadLine(), Console.WriteLine(), Hit(), Pass(), System.Environment.Exit(-1), HitOrPass(), Main()
             *
             * DESCRIPTION: Allows the player to HitOrPass() in the game interface      
             *
             * VERSION/DATE: 1.0 / 04-28 
            */


            void HitOrPass()
            {
                //Options
                Console.WriteLine("Type (h)it or (p)ass to play, (r)estart or (q)uit then type ENTER");

                input = Console.ReadLine();

                if (input == "h")
                {
                    //Hit function insert HERE
                    Console.WriteLine("You decided to HIT.");
                    Hit();

                }
                else if (input == "p")
                {
                    //Pass function insert HERE
                    Console.WriteLine("You decided to PASS.");
                    Pass();
                }
                else if (input == "r")
                {
                    //Reshuffle deck and display
                    Console.WriteLine("You decided to restart the game.");
                    winner = WINNER_ID.Undetermined;
                    is_winner = false;
                    count_deal = 0;
                    dealer_holds = false;
                    player_holds = false;
                    MainClass.Main();


                }
                else if (input == "q")
                {
                    Console.WriteLine("You decided to quit! See you next time!");
                    //end program
                    System.Environment.Exit(-1);

                }
                else
                {
                    Console.WriteLine("Invalid Entry, try again");
                    Console.WriteLine("");
                    HitOrPass();
                }
            }
            /* METHOD: Hit()
             * PARAMS: None
             * RETURNS: void
             * CLASS SCOPE EFFECTS: MainClass.count_deal, is_winner, winner, Dealer dlr, Player plr
             * 
             * CALLED FUNCTIONS: Console.ReadLine(), Console.WriteLine(), Hit(), Pass(), System.Environment.Exit(-1), HitOrPass(), Main(), TallyHand(), DrawCard(). TallyHand()
             *
             * DESCRIPTION: This is the interface that will deal the dealer and player another cards,
             * depending on the value of the hands the dealer and/or player will pass or hit again
             * 
             * VERSION/DATE: 1.0 / 04-28 
            */

            void Hit()
            {
                if (!is_winner)
                {
                    Console.WriteLine("Deal count: " + (MainClass.count_deal + 1));
                    if (dlr.ch.score < 17)
                    {
                        Console.Write("Dealer Draws: ");
                        dlr.ch.DrawCard(d.shuffledDeck[(int)((count_deal * 2) / 13), (count_deal * 2) % 13]);
                    }
                    else if (dlr.ch.score >= 17)
                    {
                        Console.WriteLine("Dealer Holds");
                        dealer_holds = true;
                    }



                    Console.Write("Player Draws: ");
                    plr.ch.DrawCard(d.shuffledDeck[(int)((count_deal * 2 + 1) / 13), ((count_deal * 2 + 1) % 13)]);

                    ++MainClass.count_deal;

                    dlr.ch.TallyHand();
                    plr.ch.TallyHand();

                }
                else
                {
                    Console.WriteLine("A winner has already been determined.");
                    Console.WriteLine("(q)uit or (r)estart to play again.");
                    input = Console.ReadLine();

                    switch (input)
                    {
                        case "q":
                            System.Environment.Exit(-1);
                            break;
                        case "r":
                            winner = WINNER_ID.Undetermined;
                            is_winner = false;
                            dealer_holds = false;
                            player_holds = false;
                            count_deal = 0;
                            MainClass.Main();

                            break;
                        default:
                            Console.WriteLine("Invalid Entry please try again.");
                            Hit();
                            break;

                    }
                }
            }
            /* METHOD: Pass()
             * PARAMS: None
             * RETURNS: void
             * CLASS SCOPE EFFECTS: is_winner, count_deal, winner, dealer_holds, player_holds, Player plr, Dealer dlr
             * 
             * CALLED FUNCTIONS: Console.ReadLine(), Console.WriteLine(), Hit(), Pass(), System.Environment.Exit(-1), HitOrPass(), Main(), TallyHand(), DrawCard(). CheckForWinner()
             * 
             * DESCRIPTION: This is the interface that allows the player to not get dealt anymore cards and stays at their current score until the Dealer holds and a
             * winner is determined
             * 
             * VERSION/DATE: 1.0 / 04-28  
            */

            void Pass()
            {
                //Checks if dealer hand is less than or equal to 17, if true deals the dealer another card
                if (!is_winner)
                {
                    player_holds = true;
                    if (dlr.ch.score < 17)
                    {
                        Console.WriteLine("Deal count: " + (MainClass.count_deal + 1));
                        Console.WriteLine("Deal draws");

                        dlr.ch.DrawCard(d.shuffledDeck[(int)((count_deal * 2) / 13), (count_deal * 2) % 13]);
                        Console.WriteLine("Player pass/holds");

                        //Increments deal count after calculating
                        ++MainClass.count_deal;

                        dlr.ch.TallyHand();
                        plr.ch.TallyHand();


                    }
                    else if (dlr.ch.score >= 17)
                    {
                        dealer_holds = true;
                        Console.WriteLine("Deal count: " + (MainClass.count_deal + 1));

                        Console.WriteLine("Dealer holds");
                        Console.WriteLine("Player holds");

                        ////Increments deal count after calculating
                        ++MainClass.count_deal;

                        dlr.ch.TallyHand();
                        plr.ch.TallyHand();

                    }
                   
                }
                else
                {
                    Console.WriteLine("A winner has already been determined.");
                    Console.WriteLine("(q)uit or (r)estart to play again.");
                    input = Console.ReadLine();

                    switch (input)
                    {
                        case "q":
                            System.Environment.Exit(-1);
                            break;
                        case "r":
                            winner = WINNER_ID.Undetermined;
                            is_winner = false;
                            count_deal = 0;
                            dealer_holds = false;
                            player_holds = false;
                            MainClass.Main();
                            break;
                        default:
                            Console.WriteLine("Invalid Entry please try again.");
                            Pass();
                            break;

                    }
                }
            }

            /* METHOD: CheckForWinner()
             * PARAMS: None
             * RETURNS: void
             * CLASS SCOPE EFFECTS: is_winner, winner
             * 
             * CALLED FUNCTIONS: Console.WriteLine()
             * 
             * DESCRIPTION: Checks if their is a winner after each card is dealt to the players
             * 
             * VERSION/DATE: 1.0 / 04-28 
            */

            void CheckForWinner()
            {
                Console.WriteLine("Checking for winner....");
                //if there is no winner, it will keep running
                if (!is_winner)
                {
                    //current scores
                    Console.WriteLine("Dealer Score: " + dlr.ch.score);
                    Console.WriteLine("Player Score: " + plr.ch.score);

                    //Checks all possible conditions
                    if (dlr.ch.score <= 21 && plr.ch.score <= 21)
                    {
                       
                        if (dlr.ch.score == 21 && plr.ch.score == 21)
                        {
                            is_winner = true;
                            winner = WINNER_ID.Tie;
                            
                        }
                        else if (dlr.ch.score == 21 && plr.ch.score != 21)
                        {
                            is_winner = true;
                            winner = WINNER_ID.Dealer;
                           
                        }
                        else if (dlr.ch.score != 21 && plr.ch.score == 21)
                        {
                            is_winner = true;
                            winner = WINNER_ID.Player;
                            
                        }

                        else if (dealer_holds && dlr.ch.score < plr.ch.score)
                        {
                            is_winner = true;
                            winner = WINNER_ID.Player;
                            
                        }

                        else if (dealer_holds && player_holds)
                        {

                            if (dlr.ch.score == plr.ch.score)
                            {
                                is_winner = true;
                                winner = WINNER_ID.Tie;
                            }
                            else if (dlr.ch.score > plr.ch.score)
                            {
                                is_winner = true;
                                winner = WINNER_ID.Dealer;
                            }
                            else if(dlr.ch.score < plr.ch.score)
                            {
                                is_winner = true;
                                winner = WINNER_ID.Player;
                            }
                            
                        }
                       
                    }
                    else if (dlr.ch.score > 21 && plr.ch.score <= 21)
                    {
                        is_winner = true;
                        winner = WINNER_ID.Player;
                    }
                    else if (plr.ch.score > 21 && dlr.ch.score <= 21)
                    {
                        is_winner = true;
                        winner = WINNER_ID.Dealer;
                       
                    }
                    else if (plr.ch.score > 21 && dlr.ch.score > 21)
                    {
                        is_winner = true;
                        winner = WINNER_ID.None;
                    }

                }
                Console.WriteLine("The winner is " + winner);


            }


        }
    }
}

